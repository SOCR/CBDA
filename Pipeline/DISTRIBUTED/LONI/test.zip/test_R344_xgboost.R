# Rscript

# THIS CHECKS THE VERSION OF R INSTALLED
version

# THIS CHECKS IF XGBOOST IS INSTALLED
library(xgboost)

print ("Status OK ... Exiting!")

q()