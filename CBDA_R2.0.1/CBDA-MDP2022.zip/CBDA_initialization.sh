#!/bin/bash

echo $1
echo $2
echo $3
echo $4
echo $5
echo $6 

export LD_PRELOAD=/usr/local/glibc-2.15/lib/libc.so.6:/usr/local/gcc-7.2.0/lib64/libstdc++.so.6:/usr/local/icu/lib/libicuuc.so.42:/usr/local/icu/lib/libicudata.so.42:/usr/local/icu/lib/libicui18n.so.42:/usr/local/icu/lib/libicui18n.so.42:/usr/local/java/java-1.7.0_64bit/lib/amd64/server/libjvm.so

#./R  --no-save --args $1 $2 $3 $4 $5 $6 < /ifs/loni/ccb/collabs/2016/CBDA_SL_2016/2018/Simeone/scripts/CBDA_pipeline_TRAINING_LG_Perl_NEW.R

cd /usr/local/R-3.5.3/bin
#./R  --no-save --args $1 $2 $3 $4 $5 $6 < /ifs/loni/ccb/collabs/2016/CBDA_SL_2016/2018/Simeone/scripts/CBDA_pipeline_TRAINING_HOPE.R
#./R  --no-save --args $1 $2 $3 $4 $5 $6 < /ifshome/smarino/scripts/CBDA_pipeline_TRAINING_HOPE.R
#./R  --no-save --args $1 $2 $3 $4 $5 $6 < /ifshome/smarino/scripts/CBDA_pipeline_TRAINING_GeoPain.R
#./R  --no-save --args $1 $2 $3 $4 $5 $6 < /ifshome/smarino/scripts/CBDA_pipeline_TRAINING_CF_new.R
./R  --no-save --args $1 $2 < $2
