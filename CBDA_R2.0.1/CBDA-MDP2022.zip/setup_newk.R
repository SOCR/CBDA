#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)
label=as.array(args[1])
workspace_directory=as.array(args[2])

print(label)
print(workspace_directory)

filename_specs <- file.path(workspace_directory,
                            paste0(label,"_validation_info.RData"))
load(filename_specs)

filename_specs_features <- file.path(workspace_directory,"featureset.txt")
write.csv(qa_ALL$Accuracy[,1],file = filename_specs_features)
## The next chunk generates the text files to be used by the
## postProcessing validation chunks
for (i in min_covs:max_covs)
{
  #k_temp <- qa_ALL$MSE[1:i]
  k_temp <- qa_ALL$Accuracy[1:i]
  #write.csv(k_temp)
  filename <- file.path(workspace_directory,paste0("newk",i,".txt"))
  k_temp1 <- paste0(as.numeric(levels(k_temp)[k_temp]), collapse=",")
  write.table(k_temp1,file=filename,row.names = FALSE,col.names = FALSE,sep = ",", eol = "\r\n" ,
              fileEncoding = "UTF-8", quote = FALSE)
}

#  save(label,workspace_directory,M,range_k,range_n,misValperc,
#       Nrow_min,Nrow_max,N_cores,Kcol_min,Kcol_max,min_covs,max_covs,
#       top,alpha,q,Xtemp,Ytemp,qa_ALL,algorithm_list, file = filename_specs)
#save(label,workspace_directory,M,misValperc,min_covs,max_covs,
#     top,qa_ALL,algorithm_list, file = filename_specs)
