#!/bin/bash

echo $1
echo $2
echo $3

#jobID={1?No job id was specified}
#label=${2?No label was specified}
#workspace_directory=${3?No workspace directory was specified}

#/usr/local/R-3.3.3/bin/R --no-save --args $jobID $label $workspace_directory < /ifshome/smarino/scripts/CBDA_pipeline_VALIDATION_LG_Perl.R

export LD_PRELOAD=/usr/local/glibc-2.15/lib/libc.so.6:/usr/local/gcc-7.2.0/lib64/libstdc++.so.6:/usr/local/icu/lib/libicuuc.so.42:/usr/local/icu/lib/libicudata.so.42:/usr/local/icu/lib/libicui18n.so.42:/usr/local/icu/lib/libicui18n.so.42:/usr/local/java/java-1.7.0_64bit/lib/amd64/server/libjvm.so

#./R  --no-save --args $1 $2 $3 $4 $5 $6 < /ifs/loni/ccb/collabs/2016/CBDA_SL_2016/2018/Simeone/scripts/CBDA_pipeline_TRAINING_LG_Perl_NEW.R

cd /usr/local/R-3.5.3/bin
#./R --no-save --args $1 $2 $3 < /ifshome/smarino/scripts/CBDA_pipeline_VALIDATION_HOPE.R
./R --no-save --args $1 $2 $3 < /ifshome/smarino/scripts/CBDA_pipeline_VALIDATION_GeoPain.R
#./R --no-save --args $1 $2 $3 < /ifshome/smarino/scripts/CBDA_pipeline_VALIDATION_CF_new.R
#./R --no-save --args $argv[1] $argv[2] $argv[3] < /ifshome/smarino/scripts/CBDA_pipeline_VALIDATION_HOPE.R
