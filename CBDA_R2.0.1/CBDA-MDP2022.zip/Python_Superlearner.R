library(SuperLearner)
require(reticulate)

#py_path = Sys.which("python3")
py_path = "C:/Program Files/Python38/python.exe"
use_python(py_path, required = 1)

#source_python("/home/mycandy/Documents/python.py")
source_python("C:/Users/simeonem/Documents/MDP-2020-2021-2022/SOCR/CBDA/python.py")
#My test wrapper
SL.linregress_py <- function(Y, X, newX, family, ...){
  fit.test <- as.data.frame(linregress_py(X$x, Y))
  colnames(fit.test) <- c("slope", "intercept", "r", "p", "se")
  pred <- as.list(fit.test$slope * newX + fit.test$intercept)$x
  fit <- list(object=fit.test)
  out <- list(pred=pred, fit=fit)
  return(out)
}

x <- runif(100, 0, 10)
y <- 2*x + 3 + rnorm(100)

#My library
SL.library <- list("SL.linregress_py")
fit <- SuperLearner(Y=y,
                    X=data.frame(x),
                    SL.library=SL.library,
                    family=gaussian(),
                    verbose=TRUE)

