#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)
print(args)
username = as.array(args[1])
print(username)
cat("CIAO !!")
A <- c(1,2,3,"test")
filename <- file.path(paste0("/ifshome/",username,"/test.csv"))
write.csv(A,filename)

