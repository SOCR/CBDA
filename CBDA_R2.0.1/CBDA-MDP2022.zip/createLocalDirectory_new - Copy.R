args = commandArgs(trailingOnly=TRUE)
username=as.array(args[1])
#project=as.array(args[2])


home_dir <- function(file) {
  return(paste0("/ifshome/", username, "/", file))
}

# dir.create(home_dir(project))
# filetemp <- paste0(project,"/Results")
# dir.create(home_dir("Project_1/Results"))
dir.create(home_dir("Project_1"))
dir.create(home_dir("Project_1/Results"))
dir.create(home_dir("scripts"))
file.copy(
  "/ifs/loni/ccb/collabs/2016/CBDA_SL_2016/2018/Simeone/scripts",
  home_dir(""),
  recursive=TRUE
)