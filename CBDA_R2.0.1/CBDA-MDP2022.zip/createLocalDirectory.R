args = commandArgs(trailingOnly=TRUE)
username=as.array(args[1])


home_dir <- function(file) {
  return(paste0("/ifshome/", username, "/", file))
}
production_run_dir <- function(file) {
  return(paste0("/ifs/loni/ccb/collabs/2016/CBDA_SL_2016/2018/Simeone/CBDA-MDP2021/",
                username, "/", file))
}

dir.create(production_run_dir("Project_1"))
dir.create(production_run_dir("Project_1/Results"))

dir.create(home_dir("Project_1"))
dir.create(home_dir("Project_1/Results"))
dir.create(home_dir("scripts"))
dir.create(home_dir("test1"))

file.copy(
  "/ifs/loni/ccb/collabs/2016/CBDA_SL_2016/2018/Simeone/scripts",
  home_dir(""),
  recursive=TRUE
)