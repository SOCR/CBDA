import numpy as np
from scipy import stats
from matplotlib import pyplot as plt

def linregress_py(x, y):
  slope, intercept, r, p, se = stats.linregress(x, y)
  return slope, intercept, r, p, se
