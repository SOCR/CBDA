args = commandArgs(trailingOnly=TRUE)
username=as.array(args[1])
#project=as.array(args[2])


final_directory <- 
  paste0("/ifs/loni/ccb/collabs/2016/CBDA_SL_2016/2018/Simeone/CBDA-MDP2021/",
         username)
unlink(final_directory)
dir.create(final_directory)
final_directory_scripts <- 
  paste0("/ifs/loni/ccb/collabs/2016/CBDA_SL_2016/2018/Simeone/CBDA-MDP2021/",
         username,"/scripts")
dir.create(final_directory_scripts)
## Here is the list of the Projects Directories
## Edit the Project name accordingly
dir.create(paste0(final_directory,"/Project_1"))
dir.create(paste0(final_directory,"/Project_1/Results"))
dir.create(paste0(final_directory,"/Project_2"))
dir.create(paste0(final_directory,"/Project_2/Results"))
dir.create(paste0(final_directory,"/Project_3"))
dir.create(paste0(final_directory,"/Project_3/Results"))
dir.create(paste0(final_directory,"/MIMIC"))
dir.create(paste0(final_directory,"/MIMIC/Results"))

list_of_files <- 
  list.files("/ifs/loni/ccb/collabs/2016/CBDA_SL_2016/2018/Simeone/CBDA-MDP2021/Simeone/scripts/", "*")
file.copy(paste0("/ifs/loni/ccb/collabs/2016/CBDA_SL_2016/2018/Simeone/CBDA-MDP2021/Simeone/scripts/",list_of_files),
          final_directory_scripts ,
          recursive=TRUE
)
# file.copy(file.path(paste0("/ifs/loni/ccb/collabs/2016/CBDA_SL_2016/2018/Simeone/CBDA-MDP2021/Simeone/scripts/",list_of_files)),
#           final_directory_scripts ,
#           recursive=TRUE
# )

#home_dir <- function(file) {
#  return(paste0("/ifshome/", username, "/", file))
#}

# dir.create(home_dir(project))
# filetemp <- paste0(project,"/Results")
# dir.create(home_dir("Project_1/Results"))
#dir.create(home_dir("Project_1"))
#dir.create(home_dir("Project_1/Results"))
#dir.create(home_dir("scripts"))
# file.copy(
#   "/ifs/loni/ccb/collabs/2016/CBDA_SL_2016/2018/Simeone/scripts",
#   home_dir(""),
#   recursive=TRUE
# )
# dir.create(final_directory)
# file.copy(
#   home_dir(""),
#   final_directory,
#   recursive=TRUE
# )


